#include <stdio.h>
#include "pico/stdlib.h"
#include "hardware/gpio.h"

#define LED_VERMELHO 10
#define LED_AMARELO 11
#define LED_VERDE 12
#define LED_PEDESTRE 6
#define BOTAO_PEDESTRE 13
#define BUZZER 27

void buzzer_beep(int duration_ms) {
    for (int i = 0; i < duration_ms / 200; i++) {
        gpio_put(BUZZER, 1);
        sleep_ms(100);
        gpio_put(BUZZER, 0);
        sleep_ms(100);
    }
}

int main() {
    stdio_init_all();

    gpio_init(LED_VERMELHO);
    gpio_init(LED_AMARELO);
    gpio_init(LED_VERDE);
    gpio_init(LED_PEDESTRE);
    gpio_init(BOTAO_PEDESTRE);
    gpio_init(BUZZER);

    gpio_set_dir(LED_VERMELHO, GPIO_OUT);
    gpio_set_dir(LED_AMARELO, GPIO_OUT);
    gpio_set_dir(LED_VERDE, GPIO_OUT);
    gpio_set_dir(LED_PEDESTRE, GPIO_OUT);
    gpio_set_dir(BUZZER, GPIO_OUT);
    gpio_set_dir(BOTAO_PEDESTRE, GPIO_IN);

    // Inicializa com todos os LEDs e buzzer desligados
    gpio_put(LED_VERMELHO, 0);
    gpio_put(LED_AMARELO, 0);
    gpio_put(LED_VERDE, 0);
    gpio_put(LED_PEDESTRE, 0);
    gpio_put(BUZZER, 0);

    while (true) {
        // Estado inicial (ciclo normal do semáforo)
        gpio_put(LED_VERDE, 1);
        sleep_ms(8000); // 8 segundos no verde
        gpio_put(LED_VERDE, 0);

        gpio_put(LED_AMARELO, 1);
        sleep_ms(2000); // 2 segundos no amarelo
        gpio_put(LED_AMARELO, 0);

        gpio_put(LED_VERMELHO, 1);
        sleep_ms(10000); // 10 segundos no vermelho
        gpio_put(LED_VERMELHO, 0);

        // Verifica se o botão foi pressionado
        if (gpio_get(BOTAO_PEDESTRE) == 1) {
            // Lógica para pedestre
            gpio_put(LED_AMARELO, 1);
            sleep_ms(5000); // 5 segundos no amarelo
            gpio_put(LED_AMARELO, 0);

            gpio_put(LED_VERMELHO, 1);
            gpio_put(LED_PEDESTRE, 1);

            buzzer_beep(15000); // Buzzer intermitente por 15 segundos

            gpio_put(LED_PEDESTRE, 0);
            gpio_put(LED_VERMELHO, 0);
        }
    }

    return 0;
}
